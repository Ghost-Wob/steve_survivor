extends CharacterBody2D
class_name Monster

@onready var sprite: Sprite2D = $Sprite2D
@onready var health_bar_bg: ColorRect = $HealthBarBG
@onready var health_bar_fill: ColorRect = $HealthBarBG/HealthBarFill
@onready var detection_area: Area2D = $Area2D

var world_type: String = "overworld"
var monster: String = "zombie"

const BASE_PATH := "res://Asset/pixel_art/monsters/"

## Stats du monstre
@export var speed: float = 64.0
@export var max_health: int = 20
@export var damage: int = 2
@export var attack_cooldown: float = 1.0
@export var detection_range: float = 16.0  # Distance pour attaquer

## Système de drops
@export var drop_scene: PackedScene
@export var drop_items: Array[String] = ["iron_ingot", "diamond"]
@export var drop_chances: Array[float] = [0.7, 0.2]
@export var drop_min: int = 1
@export var drop_max: int = 2

var current_health: int = 20
var player: Player = null
var cooldown_timer: float = 0.0
var player_in_range: bool = false

func _ready() -> void:
	_apply_texture()
	current_health = max_health
	update_health_bar()
	
	player = get_tree().get_first_node_in_group("player")
	
	# Configuration des collisions
	# Layer 3 = Monstres (pour que les armes puissent les détecter)
	set_collision_layer_value(1, false)  # Pas layer joueur
	set_collision_layer_value(2, false)  # Pas layer armes
	set_collision_layer_value(3, true)   # Layer monstres ✓
	
	# Mask = ce que le monstre détecte (rien, il traverse tout)
	set_collision_mask_value(1, false)   # Ne collide pas avec joueur
	set_collision_mask_value(2, false)   # Ne collide pas avec armes
	set_collision_mask_value(3, false)   # Ne collide pas avec autres monstres
	set_collision_mask_value(4, false)   # Ne collide pas avec map
	
	# L'Area2D gère la détection du joueur
	if detection_area:
		detection_area.body_entered.connect(_on_detection_area_entered)
		detection_area.body_exited.connect(_on_detection_area_exited)
	
	if not player:
		push_warning("Pas de joueur trouvé pour que le monstre le suive !")

func _physics_process(delta: float) -> void:
	if not player:
		return
	
	# Mise à jour du cooldown
	if cooldown_timer > 0:
		cooldown_timer -= delta
	
	# Calculer la direction vers le joueur
	var direction := (player.global_position - global_position).normalized()
	
	# Appliquer la vitesse dans cette direction
	velocity = direction * speed
	
	# Déplacer le monstre (sans collision physique)
	# On utilise move_and_collide avec Vector2.ZERO pour juste mettre à jour la position
	position += velocity * delta
	
	# Attaquer si le joueur est détecté dans l'Area2D
	if player_in_range and cooldown_timer <= 0:
		attack_player()

func _on_detection_area_entered(body: Node2D) -> void:
	if body is Player:
		player_in_range = true

func _on_detection_area_exited(body: Node2D) -> void:
	if body is Player:
		player_in_range = false

func _apply_texture() -> void:
	var path := BASE_PATH + world_type + "/" + monster + ".png"
	if ResourceLoader.exists(path):
		sprite.texture = load(path)
	else:
		push_warning("Texture introuvable : " + path)

func take_damage(amount: int) -> void:
	current_health -= amount
	update_health_bar()
	
	print("💥 ", monster, " prend ", amount, " dégâts ! (", current_health, "/", max_health, " HP)")
	
	# Effet visuel de dégât
	var tween := create_tween()
	tween.tween_property(sprite, "modulate", Color.RED, 0.1)
	tween.tween_property(sprite, "modulate", Color.WHITE, 0.1)
	
	# Knockback léger (juste visuel, pas de physique)
	var knockback_direction := (global_position - player.global_position).normalized()
	var knockback_distance := 10.0
	var knockback_tween := create_tween()
	knockback_tween.tween_property(self, "position", position + knockback_direction * knockback_distance, 0.1)
	
	if current_health <= 0:
		die()

func update_health_bar() -> void:
	if not health_bar_fill or not health_bar_bg:
		return
	
	# Calculer la largeur de la barre
	var health_percent := float(current_health) / float(max_health)
	var bar_width := health_bar_bg.size.x * health_percent
	health_bar_fill.size.x = bar_width
	
	# Changer la couleur
	if health_percent <= 0.1:
		health_bar_fill.color = Color(0.8, 0, 0)  # Rouge
	else:
		health_bar_fill.color = Color(0, 0.8, 0)  # Vert

func attack_player() -> void:
	if player:
		player.take_damage(damage)
		cooldown_timer = attack_cooldown
		
		print("👹 Zombie attaque le joueur pour ", damage, " dégâts !")

func die() -> void:
	print("💀 ", monster, " est mort !")
	
	# Drop des items
	drop_loot()
	
	# Animation de mort
	var tween := create_tween()
	tween.tween_property(sprite, "modulate:a", 0.0, 0.3)
	tween.tween_callback(queue_free)

func drop_loot() -> void:
	if not drop_scene or drop_items.is_empty():
		return
	
	# Nombre d'items à dropper
	var drop_count := randi_range(drop_min, drop_max)
	
	for i in range(drop_count):
		# Parcourir chaque item avec sa chance
		for j in range(drop_items.size()):
			var item_name: String = drop_items[j]
			var chance: float = drop_chances[j] if j < drop_chances.size() else 0.5
			
			# Test de chance
			if randf() <= chance:
				# Créer le drop
				var drop := drop_scene.instantiate() as ItemDrop
				drop.item_type = item_name
				drop.quantity = 1
				
				# Position aléatoire autour du monstre
				var offset := Vector2(randf_range(-12, 12), randf_range(-12, 12))
				drop.global_position = global_position + offset
				
				# Ajouter à la scène
				get_parent().call_deferred("add_child", drop)
				
				break  # Un seul item par itérationADWA
