extends CharacterBody2D
class_name Player

@export var speed := 128
@export var deadzone := 0.2

@export var orbit_radius := 24.0
@export var slot_count := 9
@export var orbit_rotation_speed := 1.0

## Système de vie
@export var max_health: int = 20
@export var invulnerability_time: float = 0.5

const BASE_ANGLE := 0.0

var slot_taken: Array[bool] = []
var orbit_angle: float = 0.0
var occupied_slots: int = 0

var current_health: int = 20
var is_invulnerable: bool = false

var inventory: Inventory = null

@onready var health_bar_bg: ColorRect = $HealthBarBG
@onready var health_bar_fill: ColorRect = $HealthBarBG/HealthBarFill
@onready var inventory_ui: InventoryUI = $Camera2D/CanvasLayer/InventoryUI

func _ready() -> void:
	slot_taken.resize(slot_count)
	slot_taken.fill(false)
	current_health = max_health
	
	# Créer l'inventaire
	inventory = Inventory.new()
	add_child(inventory)
	
	# Initialiser la barre de vie
	update_health_bar()
	
	# Configuration collision
	set_collision_layer_value(1, true)  # Layer 1 = joueur
	set_collision_mask_value(1, false)  # Ne collide pas avec autres joueurs
	set_collision_mask_value(2, true)   # Collide avec murs

func _physics_process(delta: float) -> void:
	var input_vector := Vector2.ZERO

	# Joystick
	var joypads := Input.get_connected_joypads()
	if joypads.size() > 0:
		var id := joypads[0]
		var joy_x := Input.get_joy_axis(id, JOY_AXIS_LEFT_X)
		var joy_y := Input.get_joy_axis(id, JOY_AXIS_LEFT_Y)
		var joy_vector := Vector2(joy_x, joy_y)
		if joy_vector.length() < deadzone:
			joy_vector = Vector2.ZERO
		else:
			input_vector = joy_vector

	# Clavier
	if input_vector == Vector2.ZERO:
		input_vector.x = Input.get_action_strength("right_move") - Input.get_action_strength("left_move")
		input_vector.y = Input.get_action_strength("bottom_move") - Input.get_action_strength("top_move")

	# Mouvement
	if input_vector != Vector2.ZERO:
		input_vector = input_vector.normalized() * speed

	velocity = input_vector
	move_and_slide()

	# Rotation des slots
	if occupied_slots > 0:
		orbit_angle += orbit_rotation_speed * delta
	else:
		orbit_angle = 0.0

# -------- SLOT SYSTEM --------

func request_slot() -> int:
	for i in range(slot_taken.size()):
		if not slot_taken[i]:
			slot_taken[i] = true
			occupied_slots += 1
			return i
	return -1

func release_slot(index: int) -> void:
	if index >= 0 and index < slot_taken.size() and slot_taken[index]:
		slot_taken[index] = false
		occupied_slots -= 1

func get_slot_transform(index: int) -> Dictionary:
	var angle := BASE_ANGLE \
		+ orbit_angle \
		+ index * (TAU / float(slot_count))

	return {
		"offset": Vector2(cos(angle), sin(angle)) * orbit_radius,
		"angle": angle
	}

# -------- COMBAT SYSTEM --------

func take_damage(amount: int) -> void:
	if is_invulnerable:
		return
	
	current_health -= amount
	update_health_bar()
	
	print("❤️ Joueur prend ", amount, " dégâts ! (", current_health, "/", max_health, " HP)")
	
	# Devenir invulnérable temporairement
	is_invulnerable = true
	
	# Effet visuel de dégât
	var sprite := $Sprite2D
	var tween := create_tween()
	tween.tween_property(sprite, "modulate", Color.RED, 0.1)
	tween.tween_property(sprite, "modulate", Color.WHITE, 0.1)
	tween.tween_property(sprite, "modulate", Color.RED, 0.1)
	tween.tween_property(sprite, "modulate", Color.WHITE, 0.1)
	
	# Fin de l'invulnérabilité
	await get_tree().create_timer(invulnerability_time).timeout
	is_invulnerable = false
	
	if current_health <= 0:
		die()

func update_health_bar() -> void:
	if not health_bar_fill or not health_bar_bg:
		return
	
	# Calculer la largeur de la barre
	var health_percent := float(current_health) / float(max_health)
	var bar_width := health_bar_bg.size.x * health_percent
	health_bar_fill.size.x = bar_width
	
	# Changer la couleur
	if health_percent <= 0.1:
		health_bar_fill.color = Color(0.8, 0, 0)  # Rouge
	else:
		health_bar_fill.color = Color(0, 0.8, 0)  # Vert

func die() -> void:
	print("💀 GAME OVER !")
	get_tree().reload_current_scene()

# -------- INVENTORY UI --------

func update_weapons_ui() -> void:
	if not inventory_ui:
		return
	
	# Récupérer toutes les armes équipées
	var equipped_weapons: Array[Weapons] = []
	var weapons := get_tree().get_nodes_in_group("equipped_weapons")
	for weapon in weapons:
		if weapon is Weapons and weapon.carrier == self:
			equipped_weapons.append(weapon)
	
#	inventory_ui.update_weapon_slots(equipped_weapons)
