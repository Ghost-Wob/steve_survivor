extends Node
class_name Inventory

signal item_added(item_type: String, quantity: int)
signal item_removed(item_type: String, quantity: int)

# Stockage des items
var items: Dictionary = {}

func add_item(item_type: String, quantity: int = 1) -> void:
	if items.has(item_type):
		items[item_type] += quantity
	else:
		items[item_type] = quantity
	
	print("📦 Ajouté à l'inventaire : ", quantity, "x ", item_type, " (Total: ", items[item_type], ")")
	item_added.emit(item_type, quantity)

func remove_item(item_type: String, quantity: int = 1) -> bool:
	if not items.has(item_type) or items[item_type] < quantity:
		return false
	
	items[item_type] -= quantity
	if items[item_type] <= 0:
		items.erase(item_type)
	
	item_removed.emit(item_type, quantity)
	return true

func get_item_count(item_type: String) -> int:
	return items.get(item_type, 0)

func has_item(item_type: String, quantity: int = 1) -> bool:
	return get_item_count(item_type) >= quantity
