extends Panel
class_name InventoryUI

@onready var items_list: VBoxContainer = $MarginContainer/VBoxContainer/ScrollContainer/ItemsList
#@onready var weapons_list: VBoxContainer = $MarginContainer/VBoxContainer/WeaponsSection/WeaponsList

var inventory: Inventory = null
var player: Player = null

func _ready() -> void:
	# Style du panel
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.1, 0.1, 0.1, 0.85)
	style.border_width_left = 2
	style.border_width_top = 2
	style.border_width_right = 2
	style.border_width_bottom = 2
	style.border_color = Color(0.3, 0.3, 0.3, 1)
	add_theme_stylebox_override("panel", style)
	
	# Trouver le joueur
	player = get_tree().get_first_node_in_group("player")
	if player:
		inventory = player.inventory
		
		# Connecter les signaux
		if inventory:
			inventory.item_added.connect(_on_item_changed)
			inventory.item_removed.connect(_on_item_changed)

func _on_item_changed(_item_type: String, _quantity: int) -> void:
	refresh_inventory()

func refresh_inventory() -> void:
	# Nettoyer l'affichage actuel
	for child in items_list.get_children():
		child.queue_free()
	
	# Afficher tous les items
	if inventory:
		for item_type: String in inventory.items.keys():
			var quantity: int = inventory.items[item_type]
			add_item_row(item_type, quantity)

func add_item_row(item_type: String, quantity: int) -> void:
	var row := HBoxContainer.new()
	row.custom_minimum_size = Vector2(0, 18)
	
	var label := Label.new()
	label.text = item_type + " x" + str(quantity)
	label.add_theme_font_size_override("font_size", 10)
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	
	row.add_child(label)
	items_list.add_child(row)

#func update_weapon_slots(weapons: Array[Weapons]) -> void:
	# Nettoyer
#	for child in weapons_list.get_children():
#		child.queue_free()
	
	# Limiter à 4 slots d'armes
#	var weapons_to_show := weapons.slice(0, 4)
	
	# Afficher les armes équipées
#	for weapon: Weapons in weapons_to_show:
#		if weapon:
#			add_weapon_row(weapon)

func add_weapon_row(weapon: Weapons) -> void:
	var row := VBoxContainer.new()
	row.custom_minimum_size = Vector2(0, 50)
	
	# Nom de l'arme
	var name_label := Label.new()
	name_label.text = weapon.rarity + " " + weapon.weapon_type
	name_label.add_theme_font_size_override("font_size", 9)
	row.add_child(name_label)
	
	# Container pour la barre
	var bar_container := ColorRect.new()
	bar_container.custom_minimum_size = Vector2(0, 8)
	bar_container.color = Color(0.2, 0.2, 0.2, 0.8)  # Fond
	
	# Barre de remplissage
	var bar_fill := ColorRect.new()
	var durability_percent := float(weapon.current_durability) / float(weapon.max_durability)
	bar_fill.size = Vector2(bar_container.custom_minimum_size.x * durability_percent, 8)
	
	if durability_percent <= 0.1:
		bar_fill.color = Color(0.8, 0, 0)  # Rouge
	else:
		bar_fill.color = Color(0, 0.7, 0.9)  # Cyan
	
	bar_container.add_child(bar_fill)
	row.add_child(bar_container)
	
	# Texte durabilité
	var durability_label := Label.new()
	durability_label.text = str(weapon.current_durability) + "/" + str(weapon.max_durability)
	durability_label.add_theme_font_size_override("font_size", 8)
	row.add_child(durability_label)
	
#	weapons_list.add_child(row)
