extends Panel
class_name ItemSlot

@onready var icon: TextureRect = $MarginContainer/VBoxContainer/Icon
@onready var quantity_label: Label = $MarginContainer/VBoxContainer/Quantity

const ITEM_TEXTURES_PATH := "res://Asset/pixel_art/items/"

func set_item(item_type: String, quantity: int) -> void:
	# Charger la texture
	var texture_path := ITEM_TEXTURES_PATH + item_type + ".png"
	if ResourceLoader.exists(texture_path):
		icon.texture = load(texture_path)
	
	# Afficher la quantité
	quantity_label.text = str(quantity)
