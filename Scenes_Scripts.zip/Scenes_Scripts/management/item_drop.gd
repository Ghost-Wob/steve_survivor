extends Node2D
class_name ItemDrop

@onready var sprite: Sprite2D = $Sprite2D

@export var item_type: String = "iron_ingot"
@export var quantity: int = 1

const BASE_PATH := "res://Asset/pixel_art/items/"

var is_being_collected: bool = false
var player: Player = null

func _ready() -> void:
	_apply_texture()
	# Animation de drop (tombe du ciel)
	var start_pos := global_position
	global_position = start_pos - Vector2(0, 20)
	var tween := create_tween()
	tween.tween_property(self, "global_position", start_pos, 0.3)
	
	# Trouver le joueur
	player = get_tree().get_first_node_in_group("player")

func _apply_texture() -> void:
	var path := BASE_PATH + item_type + ".png"
	if ResourceLoader.exists(path):
		sprite.texture = load(path)
	else:
		push_warning("Texture d'item introuvable : " + path)

func _physics_process(_delta: float) -> void:
	if is_being_collected or not player:
		return
	
	# Si le joueur est proche, attirer l'item vers lui
	var distance := global_position.distance_to(player.global_position)
	if distance < 32:
		collect()

func collect() -> void:
	if is_being_collected:
		return
	
	is_being_collected = true
	
	print("📦 Collecté : ", quantity, "x ", item_type)
	
	# Ajouter à l'inventaire du joueur
	if player and player.inventory:
		player.inventory.add_item(item_type, quantity)
	
	# Animation de collecte
	var tween := create_tween()
	tween.tween_property(self, "global_position", player.global_position, 0.3)
	tween.parallel().tween_property(sprite, "modulate:a", 0.0, 0.3)
	tween.tween_callback(queue_free)
