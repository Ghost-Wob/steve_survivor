extends Node2D
class_name MonsterSpawner

## La scène du monstre à faire spawn
@export var monster_scene: PackedScene

## Temps entre chaque spawn (en secondes)
@export var spawn_interval: float = 2.0

## Distance du joueur où les monstres apparaissent
@export var spawn_distance: float = 200.0

var spawn_timer: float = 0.0
var player: Player = null

func _ready() -> void:
	# Trouver le joueur dans la scène
	player = get_tree().get_first_node_in_group("player")
	
	if not player:
		push_error("❌ Pas de joueur trouvé ! Ajoutez le noeud Player au groupe 'player'")
	else:
		print("✅ Joueur trouvé à la position : ", player.global_position)
	
	if not monster_scene:
		push_error("❌ Aucune scène de monstre assignée dans l'inspecteur !")
	else:
		print("✅ Scène de monstre chargée : ", monster_scene.resource_path)

func _process(delta: float) -> void:
	if not player or not monster_scene:
		return
	
	# Compter le temps
	spawn_timer += delta
	
	# Quand le temps est écoulé, spawn un monstre
	if spawn_timer >= spawn_interval:
		spawn_timer = 0.0
		spawn_monster()

func spawn_monster() -> void:
	print("🎯 Tentative de spawn de monstre...")
	
	# Créer une position aléatoire autour du joueur
	var angle := randf() * TAU
	var spawn_pos := player.global_position + Vector2(cos(angle), sin(angle)) * spawn_distance
	
	print("📍 Position de spawn : ", spawn_pos)
	
	# Créer le monstre
	var monster := monster_scene.instantiate()
	monster.global_position = spawn_pos
	
	print("👹 Monstre créé !")
	
	# Ajouter le monstre à la scène
	get_parent().add_child(monster)
	
	print("✅ Monstre ajouté à la scène à ", monster.global_position)
