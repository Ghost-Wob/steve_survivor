extends Node2D
class_name Weapons

@onready var sprite: Sprite2D = $Sprite2D
@onready var hit_area: Area2D = $Area2D

var weapon_type: String = "sword"
var rarity: String = "wooden"

const BASE_PATH := "res://Asset/pixel_art/weapons/"
const VISUAL_ROTATION_OFFSET := PI / 4.0

var carrier: Player = null
var slot_index: int = -1

## Système de dégâts et durabilité
var damage: int = 1
var max_durability: int = 59
var current_durability: int = 59
var attack_cooldown: float = 0.625
var cooldown_timer: float = 0.0

# Pour éviter de taper plusieurs fois le même monstre
var monsters_in_range: Array[Monster] = []
var recently_hit: Dictionary = {}  # {monster_instance_id: timestamp}

# Dictionnaire des stats par rareté
const RARITY_STATS := {
	"wooden": {"damage": 4, "durability": 59},
	"stone": {"damage": 5, "durability": 131},
	"iron": {"damage": 6, "durability": 250},
	"gold": {"damage": 4, "durability": 32},
	"diamond": {"damage": 7, "durability": 1561},
	"netherite": {"damage": 8, "durability": 2031}
}

func _ready() -> void:
	_apply_texture()
	add_to_group("equipped_weapons")
	
	# Connecter les signaux de l'Area2D
	if hit_area:
		hit_area.body_entered.connect(_on_body_entered_range)
		hit_area.body_exited.connect(_on_body_exited_range)
		hit_area.area_entered.connect(_on_area_entered_range)

func _physics_process(delta: float) -> void:
	# Mise à jour du cooldown
	if cooldown_timer > 0:
		cooldown_timer -= delta
	
	# Rotation autour du joueur
	if carrier and slot_index != -1:
		var data := carrier.get_slot_transform(slot_index)
		global_position = carrier.global_position + data.offset
		sprite.rotation = data.angle + VISUAL_ROTATION_OFFSET
		
		# Attaquer les monstres dans la zone
		if cooldown_timer <= 0:
			attack_monsters_in_range()

func _on_body_entered_range(body: Node2D) -> void:
	# Détecter le joueur pour ramassage
	if body is Player and carrier == null:
		pickup_weapon(body)
	# Détecter les monstres
	elif body is Monster and body not in monsters_in_range:
		monsters_in_range.append(body)

func _on_body_exited_range(body: Node2D) -> void:
	if body is Monster and body in monsters_in_range:
		monsters_in_range.erase(body)

func _on_area_entered_range(area: Area2D) -> void:
	# Si c'est l'Area2D d'un monstre (pour compatibilité)
	var parent = area.get_parent()
	if parent is Monster and parent not in monsters_in_range:
		monsters_in_range.append(parent)

func pickup_weapon(player: Player) -> void:
	var slot := player.request_slot()
	
	if slot == -1:
		rarity = "netherite"
		_apply_texture()
		return
	
	carrier = player
	slot_index = slot
	rarity = "netherite"
	_apply_texture()
	
	# Mettre à jour l'UI d'inventaire
	player.update_weapons_ui()

func attack_monsters_in_range() -> void:
	if not carrier:
		return
	
	# Nettoyer les monstres morts de la liste
	monsters_in_range = monsters_in_range.filter(func(m): return is_instance_valid(m))
	
	# Nettoyer les timestamps anciens
	var current_time := Time.get_ticks_msec()
	var ids_to_remove: Array[int] = []
	for monster_id in recently_hit.keys():
		if current_time - recently_hit[monster_id] > 500:  # 500ms de protection
			ids_to_remove.append(monster_id)
	for id in ids_to_remove:
		recently_hit.erase(id)
	
	# Attaquer chaque monstre dans la zone
	for monster in monsters_in_range:
		if not is_instance_valid(monster):
			continue
		
		var monster_id := monster.get_instance_id()
		
		# Vérifier si on a déjà tapé ce monstre récemment
		if recently_hit.has(monster_id):
			continue
		
		# Infliger les dégâts
		monster.take_damage(damage)
		recently_hit[monster_id] = current_time
		
		# Réduire la durabilité
		current_durability -= 1
		
		# Mettre à jour l'UI
		if carrier:
			carrier.update_weapons_ui()
		
		# Démarrer le cooldown
		cooldown_timer = attack_cooldown
		
		# Effet visuel d'attaque
		var tween := create_tween()
		tween.tween_property(sprite, "modulate", Color.RED, 0.1)
		tween.tween_property(sprite, "modulate", Color.WHITE, 0.1)
		
		# Vérifier si l'arme est cassée
		if current_durability <= 0:
			break_weapon()
			return
		
		# Une seule attaque par frame
		break

func _apply_texture() -> void:
	var path := BASE_PATH + weapon_type + "s/" + rarity + "_" + weapon_type + ".png"
	if ResourceLoader.exists(path):
		sprite.texture = load(path)
		
		# Appliquer les stats selon la rareté
		if RARITY_STATS.has(rarity):
			var stats = RARITY_STATS[rarity]
			damage = stats["damage"]
			max_durability = stats["durability"]
			current_durability = max_durability
	else:
		push_warning("Texture introuvable : " + path)

func break_weapon() -> void:
	print("💔 L'arme ", rarity, " ", weapon_type, " est cassée !")
	
	if carrier:
		carrier.release_slot(slot_index)
		carrier.update_weapons_ui()
	
	var tween := create_tween()
	tween.tween_property(sprite, "modulate:a", 0.0, 0.3)
	tween.tween_callback(queue_free)
